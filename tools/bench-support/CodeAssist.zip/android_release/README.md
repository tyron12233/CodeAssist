# CodeAssist — Android Launcher Icon (Direction D · "Depth Echo")

Adaptive launcher icon: two glass C's (teal echo behind violet) + a white caret,
on the CodeAssist dark-warm ground. Drawn on the standard 108dp full-bleed grid;
the glyph sits inside the 66dp safe-zone circle.

## Contents

```
res/
  mipmap-anydpi-v26/
    ic_launcher.xml            adaptive icon (background + foreground + monochrome)
    ic_launcher_round.xml      same, for roundIcon
  mipmap-{mdpi,hdpi,xhdpi,xxhdpi,xxxhdpi}/
    ic_launcher_background.png   full-bleed ground (108dp base: 108/162/216/324/432 px)
    ic_launcher_foreground.png   glyph layer, transparent
    ic_launcher_monochrome.png   flat silhouette for Android 13+ themed icons
src/
  *.svg                        vector sources (master artwork)
```

## Wiring

1. Copy everything under `res/` into your module's `src/main/res/`.
2. In `AndroidManifest.xml`:

```xml
<application
    android:icon="@mipmap/ic_launcher"
    android:roundIcon="@mipmap/ic_launcher_round"
    ... >
```

## Notes

- **Why PNG layers (not VectorDrawable):** the glassy finish uses Gaussian-blur
  glows and layered translucency, which `VectorDrawable` cannot express. The
  SVG sources in `src/` are the masters if you ever need to re-cut.
- **Monochrome layer** is intentionally flat (no glow/echo) — Android tints it
  for Material You themed icons, so it must be a clean single-color silhouette.
- **Legacy (< API 26) fallback:** not included. If you support pre-26 devices,
  flatten background+foreground and export masked 48dp `ic_launcher.png` at each
  density — happy to generate these.
- Play Store listing icon (512×512, no mask) is also not included yet — ask if needed.
